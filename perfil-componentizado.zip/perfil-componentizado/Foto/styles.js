import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    alinhaFoto:{
        alignItems: 'center'
    },
});

export {styles}